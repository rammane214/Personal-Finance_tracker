package com.finance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseCheck {
    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finance_db", "root", "RamMane214#");
            if (conn == null) {
                System.out.println("❌ Database connection failed");
                return;
            }
            
            System.out.println("✅ Database connected successfully");
            
            Statement stmt = conn.createStatement();
            
            // Check if transactions table exists
            System.out.println("\n🔍 Checking transactions table...");
            try {
                ResultSet rs = stmt.executeQuery("DESCRIBE transactions");
                System.out.println("✅ Transactions table exists");
                System.out.println("Table structure:");
                while (rs.next()) {
                    System.out.println("  - " + rs.getString("Field") + ": " + rs.getString("Type"));
                }
                rs.close();
                
                // Check data count
                rs = stmt.executeQuery("SELECT COUNT(*) as count FROM transactions");
                if (rs.next()) {
                    int count = rs.getInt("count");
                    System.out.println("📊 Total records in transactions: " + count);
                }
                rs.close();
                
                // Show recent transactions
                rs = stmt.executeQuery("SELECT type, amount, description, date FROM transactions ORDER BY date DESC LIMIT 5");
                System.out.println("\n📝 Recent transactions:");
                while (rs.next()) {
                    System.out.println("  " + rs.getString("type") + ": " + rs.getDouble("amount") + " - " + rs.getString("description") + " (" + rs.getString("date") + ")");
                }
                rs.close();
                
            } catch (SQLException e) {
                System.out.println("❌ Transactions table does not exist: " + e.getMessage());
                System.out.println("🔧 Creating transactions table...");
                
                // Create transactions table
                String createTable = "CREATE TABLE transactions (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "user_id INT, " +
                    "type VARCHAR(10) NOT NULL, " +
                    "amount DOUBLE NOT NULL, " +
                    "description VARCHAR(255), " +
                    "category VARCHAR(100), " +
                    "date DATE, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ")";
                
                stmt.execute(createTable);
                System.out.println("✅ Transactions table created successfully");
                
                // Insert sample data
                String[] sampleData = {
                    "INSERT INTO transactions (user_id, type, amount, description, category, date) VALUES (1, 'income', 50000.00, 'Monthly Salary', 'Salary', '2024-01-01')",
                    "INSERT INTO transactions (user_id, type, amount, description, category, date) VALUES (1, 'expense', 1500.00, 'Grocery Shopping', 'Food', '2024-01-05')",
                    "INSERT INTO transactions (user_id, type, amount, description, category, date) VALUES (1, 'expense', 2000.00, 'Electric Bill', 'Bills', '2024-01-10')"
                };
                
                for (String sql : sampleData) {
                    stmt.execute(sql);
                }
                System.out.println("✅ Sample data inserted");
            }
            
            // Test expense insertion
            System.out.println("\n🧪 Testing expense insertion...");
            try {
                int result = stmt.executeUpdate("INSERT INTO transactions (user_id, type, amount, description, category, date) VALUES (1, 'expense', 100.00, 'Test Expense', 'Test', CURDATE())");
                if (result > 0) {
                    System.out.println("✅ Test expense inserted successfully");
                } else {
                    System.out.println("❌ Test expense insertion failed");
                }
            } catch (SQLException e) {
                System.out.println("❌ Test expense insertion failed: " + e.getMessage());
            }
            
            stmt.close();
            conn.close();
            
            System.out.println("\n🎉 Database check completed!");
            
        } catch (SQLException e) {
            System.out.println("❌ Database error: " + e.getMessage());
        }
    }
}
