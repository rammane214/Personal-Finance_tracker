package com.finance;

public class BudgetAlert extends Thread {
    private boolean running = true;
    private FinanceTrackerGUI gui;

    public BudgetAlert() {
        // Default constructor for backward compatibility
    }

    public BudgetAlert(FinanceTrackerGUI gui) {
        this.gui = gui;
    }

    public void setGUI(FinanceTrackerGUI gui) {
        this.gui = gui;
    }

    public void stopMonitoring() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            double total = DataStore.getTotalExpenses();
            if (total > 5000) {
                String alertMessage = "BUDGET ALERT: Expenses $" + total + " exceeded $5000!";
                if (gui != null) {
                    gui.displayAlert(alertMessage);
                } else {
                    System.out.println(alertMessage);
                }
            }

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
