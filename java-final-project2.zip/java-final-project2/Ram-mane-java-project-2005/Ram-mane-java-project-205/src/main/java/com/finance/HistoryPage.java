package com.finance;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class HistoryPage extends JFrame {
    
    // Search components
    private JTextField searchDateField;
    private JTextField searchSpecificDateField;
    private JTextField searchMonthField;
    private JTextField searchYearField;
    private JComboBox<String> searchTypeCombo;
    private JTextArea outputArea;
    
    private static final DecimalFormat CURRENCY_FORMAT = new DecimalFormat("$#,##0.00");
    
    public HistoryPage() {
        initializeGUI();
        loadRecentTransactions();
    }
    
    private void initializeGUI() {
        setTitle("Finance History - Search & Analytics");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        
        // Title
        JLabel titleLabel = new JLabel("Finance History Search", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);
        
        // Main content
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Search panel
        JPanel searchPanel = createSearchPanel();
        mainPanel.add(searchPanel, BorderLayout.NORTH);
        
        // Output area
        outputArea = new JTextArea(20, 60);
        outputArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        outputArea.setEditable(false);
        outputArea.setBackground(new Color(248, 248, 248));
        outputArea.setMargin(new Insets(10, 10, 10, 10));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(mainPanel, BorderLayout.CENTER);
    }
    
    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Search Controls
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.1;
        panel.add(new JLabel("Type:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.15;
        searchTypeCombo = new JComboBox<>(new String[]{"All", "Income", "Expense"});
        searchTypeCombo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        panel.add(searchTypeCombo, gbc);

        // Specific Date Search
        gbc.gridx = 2;
        gbc.weightx = 0.1;
        panel.add(new JLabel("Specific Date:"), gbc);

        gbc.gridx = 3;
        gbc.weightx = 0.15;
        searchSpecificDateField = new JTextField(12);
        searchSpecificDateField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchSpecificDateField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchSpecificDateField.setToolTipText("YYYY-MM-DD");
        panel.add(searchSpecificDateField, gbc);

        gbc.gridx = 4;
        gbc.weightx = 0.1;
        JButton searchSpecificButton = createSearchButton("Search Date");
        searchSpecificButton.addActionListener(e -> searchSpecificDate());
        panel.add(searchSpecificButton, gbc);

        // Date Range Search
        gbc.gridx = 5;
        gbc.weightx = 0.1;
        panel.add(new JLabel("Date Range:"), gbc);

        gbc.gridx = 6;
        gbc.gridwidth = 2;
        gbc.weightx = 0.2;
        searchDateField = new JTextField(15);
        searchDateField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchDateField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchDateField.setToolTipText("YYYY-MM-DD to YYYY-MM-DD");
        panel.add(searchDateField, gbc);

        gbc.gridx = 8;
        gbc.gridwidth = 1;
        gbc.weightx = 0.1;
        JButton searchRangeButton = createSearchButton("Search Range");
        searchRangeButton.addActionListener(e -> searchDateRange());
        panel.add(searchRangeButton, gbc);

        // Quick Search Buttons
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.1;
        JButton searchTodayButton = createSearchButton("Today");
        searchTodayButton.addActionListener(e -> searchToday());
        panel.add(searchTodayButton, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.1;
        JButton searchThisMonthButton = createSearchButton("This Month");
        searchThisMonthButton.addActionListener(e -> searchThisMonth());
        panel.add(searchThisMonthButton, gbc);

        // Period Search
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.weightx = 0.1;
        panel.add(new JLabel("Month:"), gbc);

        gbc.gridx = 3;
        gbc.weightx = 0.1;
        searchMonthField = new JTextField(8);
        searchMonthField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchMonthField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchMonthField.setToolTipText("MM format (01-12)");
        panel.add(searchMonthField, gbc);

        gbc.gridx = 4;
        gbc.weightx = 0.08;
        panel.add(new JLabel("Year:"), gbc);

        gbc.gridx = 5;
        gbc.weightx = 0.1;
        searchYearField = new JTextField(8);
        searchYearField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchYearField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchYearField.setToolTipText("YYYY format");
        panel.add(searchYearField, gbc);

        gbc.gridx = 6;
        gbc.weightx = 0.1;
        JButton searchMonthlyButton = createSearchButton("Search Month");
        searchMonthlyButton.addActionListener(e -> searchMonthly());
        panel.add(searchMonthlyButton, gbc);

        gbc.gridx = 7;
        gbc.weightx = 0.1;
        JButton searchYearlyButton = createSearchButton("Search Year");
        searchYearlyButton.addActionListener(e -> searchYearly());
        panel.add(searchYearlyButton, gbc);

        // Action Buttons
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 0.2;
        JButton clearSearchButton = createSearchButton("Clear Search");
        clearSearchButton.addActionListener(e -> clearSearch());
        panel.add(clearSearchButton, gbc);

        gbc.gridx = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 0.2;
        JButton refreshButton = createSearchButton("Refresh");
        refreshButton.addActionListener(e -> loadRecentTransactions());
        panel.add(refreshButton, gbc);

        gbc.gridx = 4;
        gbc.gridwidth = 2;
        gbc.weightx = 0.2;
        JButton returnButton = createSearchButton("Return to Main");
        returnButton.addActionListener(e -> returnToMain());
        panel.add(returnButton, gbc);

        gbc.gridx = 6;
        gbc.gridwidth = 2;
        gbc.weightx = 0.2;
        JButton closeButton = createSearchButton("Close");
        closeButton.addActionListener(e -> dispose());
        panel.add(closeButton, gbc);

        return panel;
    }
    
    private JButton createSearchButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        button.setPreferredSize(new Dimension(120, 28));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createLineBorder(new Color(50, 110, 160), 1));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(90, 150, 200));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(70, 130, 180));
            }
        });

        return button;
    }
    
    private void loadRecentTransactions() {
        searchAllData("Recent Transactions (Last 50)");
    }
    
    private void searchSpecificDate() {
        String specificDate = searchSpecificDateField.getText().trim();
        if (specificDate.isEmpty()) {
            outputArea.append("Please enter a specific date (YYYY-MM-DD)\n");
            return;
        }

        searchTransactionsByDate("DATE(date) = DATE(?)", specificDate, "Specific Date History (" + specificDate + ")");
    }
    
    private void searchDateRange() {
        String dateRange = searchDateField.getText().trim();
        if (dateRange.isEmpty()) {
            outputArea.append("Please enter a date range (YYYY-MM-DD to YYYY-MM-DD)\n");
            return;
        }

        if (dateRange.contains(" to ")) {
            String[] dates = dateRange.split(" to ");
            searchTransactionsByDate("date BETWEEN ? AND ?", dates, "Date Range History (" + dateRange + ")");
        } else {
            searchTransactionsByDate("DATE(date) = DATE(?)", dateRange, "Date History (" + dateRange + ")");
        }
    }

    private void searchToday() {
        searchTransactionsByDate("DATE(date) = CURDATE()", "", "Today's History");
    }

    private void searchThisMonth() {
        searchTransactionsByDate("MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())", "",
                "This Month's History");
    }

    private void searchMonthly() {
        String month = searchMonthField.getText().trim();
        if (month.isEmpty()) {
            outputArea.append("Please enter a month (MM)\n");
            return;
        }

        searchTransactionsByDate("MONTH(date) = ?", month, "Monthly History (Month " + month + ")");
    }

    private void searchYearly() {
        String year = searchYearField.getText().trim();
        if (year.isEmpty()) {
            outputArea.append("Please enter a year (YYYY)\n");
            return;
        }

        searchTransactionsByDate("YEAR(date) = ?", year, "Yearly History (Year " + year + ")");
    }

    private void searchAllData(String title) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finance_db", "root", "RamMane214#")) {
            List<TransactionData> results = new ArrayList<>();
            
            // Get income data
            String incomeSql = "SELECT 'income' as type, amount, source as description, source as category, date FROM income ORDER BY date DESC LIMIT 25";
            try (PreparedStatement incomeStmt = conn.prepareStatement(incomeSql);
                 ResultSet incomeRs = incomeStmt.executeQuery()) {
                
                while (incomeRs.next()) {
                    results.add(new TransactionData(
                        incomeRs.getString("type"),
                        incomeRs.getDouble("amount"),
                        incomeRs.getString("description"),
                        incomeRs.getString("category"),
                        incomeRs.getString("date")
                    ));
                }
            }
            
            // Get expense data
            String expenseSql = "SELECT 'expense' as type, amount, category as description, category, date FROM expense ORDER BY date DESC LIMIT 25";
            try (PreparedStatement expenseStmt = conn.prepareStatement(expenseSql);
                 ResultSet expenseRs = expenseStmt.executeQuery()) {
                
                while (expenseRs.next()) {
                    results.add(new TransactionData(
                        expenseRs.getString("type"),
                        expenseRs.getDouble("amount"),
                        expenseRs.getString("description"),
                        expenseRs.getString("category"),
                        expenseRs.getString("date")
                    ));
                }
            }
            
            displayResults(results, title, "All");
            
        } catch (SQLException e) {
            outputArea.append("Error searching history: " + e.getMessage() + "\n");
        }
    }

    private void searchTransactionsByDate(String dateCondition, Object dateParams, String title) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finance_db", "root", "RamMane214#")) {
            String selectedType = (String) searchTypeCombo.getSelectedItem();
            List<TransactionData> results = new ArrayList<>();
            
            // Get income data if needed
            if ("All".equals(selectedType) || "Income".equals(selectedType)) {
                String incomeSql = "SELECT 'income' as type, amount, source as description, source as category, date FROM income";
                if (!dateCondition.equals("1=1")) {
                    incomeSql += " WHERE " + dateCondition;
                }
                incomeSql += " ORDER BY date DESC";
                if ("All".equals(selectedType)) {
                    incomeSql += " LIMIT 25";
                } else if ("Income".equals(selectedType)) {
                    incomeSql += " LIMIT 50";
                }
                
                try (PreparedStatement incomeStmt = conn.prepareStatement(incomeSql)) {
                    
                    // Set date parameters for income
                    if (!dateCondition.equals("1=1")) {
                        int paramIndex = 1;
                        if (dateParams instanceof Object[]) {
                            Object[] dates = (Object[]) dateParams;
                            for (Object date : dates) {
                                incomeStmt.setString(paramIndex++, date.toString());
                            }
                        } else if (!dateParams.toString().isEmpty()) {
                            incomeStmt.setString(paramIndex++, dateParams.toString());
                        }
                    }
                    
                    try (ResultSet incomeRs = incomeStmt.executeQuery()) {
                        while (incomeRs.next()) {
                            results.add(new TransactionData(
                                incomeRs.getString("type"),
                                incomeRs.getDouble("amount"),
                                incomeRs.getString("description"),
                                incomeRs.getString("category"),
                                incomeRs.getString("date")
                            ));
                        }
                    }
                }
            }
            
            // Get expense data if needed
            if ("All".equals(selectedType) || "Expense".equals(selectedType)) {
                String expenseSql = "SELECT 'expense' as type, amount, category as description, category, date FROM expense";
                if (!dateCondition.equals("1=1")) {
                    expenseSql += " WHERE " + dateCondition;
                }
                expenseSql += " ORDER BY date DESC";
                if ("All".equals(selectedType)) {
                    expenseSql += " LIMIT 25";
                } else if ("Expense".equals(selectedType)) {
                    expenseSql += " LIMIT 50";
                }
                
                try (PreparedStatement expenseStmt = conn.prepareStatement(expenseSql)) {
                    
                    // Set date parameters for expense
                    if (!dateCondition.equals("1=1")) {
                        int paramIndex = 1;
                        if (dateParams instanceof Object[]) {
                            Object[] dates = (Object[]) dateParams;
                            for (Object date : dates) {
                                expenseStmt.setString(paramIndex++, date.toString());
                            }
                        } else if (!dateParams.toString().isEmpty()) {
                            expenseStmt.setString(paramIndex++, dateParams.toString());
                        }
                    }
                    
                    try (ResultSet expenseRs = expenseStmt.executeQuery()) {
                        while (expenseRs.next()) {
                            results.add(new TransactionData(
                                expenseRs.getString("type"),
                                expenseRs.getDouble("amount"),
                                expenseRs.getString("description"),
                                expenseRs.getString("category"),
                                expenseRs.getString("date")
                            ));
                        }
                    }
                }
            }
            
            displayResults(results, title, selectedType);
            
        } catch (SQLException e) {
            outputArea.append("Error searching history: " + e.getMessage() + "\n");
        }
    }

    private void displayResults(List<TransactionData> results, String title, String selectedType) {
        outputArea.setText(""); // Clear existing text
        outputArea.append("=== " + title.toUpperCase() + " ===\n");
        outputArea.append("Generated: " + new java.util.Date() + "\n");
        outputArea.append("=====================================\n\n");
        
        if (results.isEmpty()) {
            outputArea.append("No transactions found matching your criteria.\n");
            outputArea.append("=====================================\n\n");
            return;
        }
        
        double totalIncome = 0, totalExpense = 0;
        int transactionCount = 0;

        for (TransactionData data : results) {
            transactionCount++;
            
            if ("income".equals(data.type)) {
                totalIncome += data.amount;
                outputArea.append(String.format("INCOME:  %s from %s (%s) [%s]\n", 
                    CURRENCY_FORMAT.format(data.amount), data.description, data.date, data.category));
            } else {
                totalExpense += data.amount;
                outputArea.append(String.format("EXPENSE: %s for %s (%s) [%s]\n", 
                    CURRENCY_FORMAT.format(data.amount), data.description, data.date, data.category));
            }
        }

        outputArea.append("\n--- SEARCH SUMMARY ---\n");
        outputArea.append(String.format("Total Transactions: %d\n", transactionCount));
        outputArea.append(String.format("Total Income:     %s\n", CURRENCY_FORMAT.format(totalIncome)));
        outputArea.append(String.format("Total Expense:    %s\n", CURRENCY_FORMAT.format(totalExpense)));
        outputArea.append(String.format("Net Balance:      %s\n", CURRENCY_FORMAT.format(totalIncome - totalExpense)));
        if (transactionCount > 0) {
            outputArea.append(String.format("Average Transaction: %s\n", CURRENCY_FORMAT.format((totalIncome + totalExpense) / transactionCount)));
        }
        
        if (!"All".equals(selectedType)) {
            outputArea.append(String.format("Type Filter:       '%s'\n", selectedType));
        }
        outputArea.append("=====================================\n\n");
    }

    private void clearSearch() {
        searchDateField.setText("");
        searchSpecificDateField.setText("");
        searchMonthField.setText("");
        searchYearField.setText("");
        searchTypeCombo.setSelectedIndex(0);
        loadRecentTransactions();
    }

    private void returnToMain() {
        // Close the history page and show the main GUI
        this.dispose();
        SwingUtilities.invokeLater(() -> {
            try {
                FinanceTrackerGUI mainGUI = new FinanceTrackerGUI();
                mainGUI.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error opening main page: " + e.getMessage(), 
                                            "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Helper class to store transaction data
    private static class TransactionData {
        String type;
        double amount;
        String description;
        String category;
        String date;

        TransactionData(String type, double amount, String description, String category, String date) {
            this.type = type;
            this.amount = amount;
            this.description = description;
            this.category = category;
            this.date = date;
        }
    }
}
