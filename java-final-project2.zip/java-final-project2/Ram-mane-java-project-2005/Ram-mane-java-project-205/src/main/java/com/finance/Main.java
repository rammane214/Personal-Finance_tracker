package com.finance;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    FinanceTrackerGUI gui = new FinanceTrackerGUI();
                    gui.setVisible(true);
                } catch (Exception e) {
                    System.out.println("Error launching GUI: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }
}
