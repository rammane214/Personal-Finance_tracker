package com.finance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class IncomeDAO {
    public static boolean addIncome(double amount, String source, String date) {
        String sql = "INSERT INTO income (amount, source, date) VALUES (?, ?, ?)";

        try {
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                System.out.println("Error: Database connection failed");
                return false;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setDouble(1, amount);
                pstmt.setString(2, source);
                pstmt.setString(3, date);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println("Income added - Rows affected: " + rowsAffected);
                return rowsAffected > 0;
            } finally {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Error adding income: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
