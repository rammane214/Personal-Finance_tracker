package com.finance;

import java.util.ArrayList;

public class DataStore {
    private static ArrayList<Double> expenses = new ArrayList<>();
    
    public static void addExpense(double amount) {
        expenses.add(amount);
    }
    
    public static double getTotalExpenses() {
        double total = 0;
        for (double expense : expenses) {
            total  = total + expense;
        }
        return total;
    }
}
