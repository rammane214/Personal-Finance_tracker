package com.finance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.DecimalFormat;

public class FinanceTrackerGUI extends JFrame {
    private static BudgetAlert budgetAlert;

    private JTextField incomeAmountField;
    private JTextField incomeSourceField;
    private JTextField incomeDateField;
    private JTextField expenseAmountField;
    private JTextField expenseCategoryField;
    private JTextField expenseDateField;
    private JTextArea outputArea;

    // History search components
    private JTextField searchDateField;
    private JTextField searchMonthField;
    private JTextField searchYearField;
    private JTextField searchKeywordField;
    private JComboBox<String> searchTypeCombo;
    private JComboBox<String> searchSortCombo;

    private static final DecimalFormat CURRENCY_FORMAT = new DecimalFormat("$#,##0.00");

    public FinanceTrackerGUI() {
        initializeGUI();
        initializeBudgetAlert();
    }

    private void initializeBudgetAlert() {
        budgetAlert = new BudgetAlert(this);
        budgetAlert.start();
    }

    public void displayAlert(String message) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                outputArea.append(message + "\n");
                outputArea.setCaretPosition(outputArea.getDocument().getLength());
            }
        });
    }

    private void initializeGUI() {
        setTitle("Personal Finance Tracker");
        setSize(750, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        mainPanel.add(createInputPanel(), BorderLayout.CENTER);
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setPreferredSize(new Dimension(750, 50));
        headerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)));

        JLabel titleLabel = new JLabel("Personal Finance Tracker");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(Color.BLACK);
        headerPanel.add(titleLabel);

        return headerPanel;
    }

    private JPanel createInputPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.WHITE);

        // Income Section
        mainPanel.add(createSectionPanel("Income", createIncomeFieldPanel()));
        mainPanel.add(Box.createVerticalStrut(8));

        // Expense Section
        mainPanel.add(createSectionPanel("Expense", createExpenseFieldPanel()));
        mainPanel.add(Box.createVerticalStrut(8));

        // Output Section
        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.setBackground(Color.WHITE);
        outputArea = new JTextArea(10, 40);
        outputArea.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        outputArea.setEditable(false);
        outputArea.setBackground(new Color(248, 248, 248));
        outputArea.setMargin(new Insets(8, 8, 8, 8));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 1));

        JLabel outputLabel = new JLabel("Activity Log");
        outputLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        outputLabel.setForeground(Color.BLACK);

        JPanel outputHeaderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        outputHeaderPanel.setBackground(Color.WHITE);
        outputHeaderPanel.add(outputLabel);

        outputPanel.add(outputHeaderPanel, BorderLayout.NORTH);
        outputPanel.add(Box.createVerticalStrut(5), BorderLayout.NORTH);
        outputPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(outputPanel);
        mainPanel.add(Box.createVerticalGlue());

        return mainPanel;
    }

    private JPanel createIncomeFieldPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.25;
        panel.add(new JLabel("Amount:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.75;
        incomeAmountField = new JTextField(12);
        incomeAmountField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        incomeAmountField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        panel.add(incomeAmountField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.25;
        panel.add(new JLabel("Source:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.75;
        incomeSourceField = new JTextField(12);
        incomeSourceField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        incomeSourceField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        panel.add(incomeSourceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.25;
        panel.add(new JLabel("Date:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.75;
        incomeDateField = new JTextField(12);
        incomeDateField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        incomeDateField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        incomeDateField.setToolTipText("YYYY-MM-DD format");
        panel.add(incomeDateField, gbc);

        return panel;
    }

    private JPanel createExpenseFieldPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.25;
        panel.add(new JLabel("Amount:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.75;
        expenseAmountField = new JTextField(12);
        expenseAmountField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        expenseAmountField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        panel.add(expenseAmountField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.25;
        panel.add(new JLabel("Category:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.75;
        expenseCategoryField = new JTextField(12);
        expenseCategoryField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        expenseCategoryField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        panel.add(expenseCategoryField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.25;
        panel.add(new JLabel("Date:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.75;
        expenseDateField = new JTextField(12);
        expenseDateField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        expenseDateField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        expenseDateField.setToolTipText("YYYY-MM-DD format");
        panel.add(expenseDateField, gbc);

        return panel;
    }

    private JPanel createSectionPanel(String title, JPanel contentPanel) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230), 1));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLabel.setForeground(Color.BLACK);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(220, 220, 220)));

        JButton addIncomeButton = createButton("Add Income");
        addIncomeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addIncome();
            }
        });
        panel.add(addIncomeButton);

        JButton addExpenseButton = createButton("Add Expense");
        addExpenseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addExpense();
            }
        });
        panel.add(addExpenseButton);

        JButton viewHistoryButton = createButton("View History");
        viewHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openHistoryPage();
            }
        });
        panel.add(viewHistoryButton);

        JButton stopAlertButton = createButton("Stop Budget Alert");
        stopAlertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopBudgetAlert();
            }
        });
        panel.add(stopAlertButton);

        JButton exitButton = createButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitApplication();
            }
        });
        panel.add(exitButton);

        return panel;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        button.setPreferredSize(new Dimension(110, 32));
        button.setBackground(Color.WHITE);
        button.setForeground(Color.BLACK);
        button.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180), 1));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(245, 245, 245));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.WHITE);
            }
        });

        return button;
    }

    private void addIncome() {
        try {
            String amountText = incomeAmountField.getText().trim();
            String source = incomeSourceField.getText().trim();
            String date = incomeDateField.getText().trim();

            if (amountText.isEmpty() || source.isEmpty() || date.isEmpty()) {
                outputArea.append("Please fill in all income fields\n");
                return;
            }

            double amount = Double.parseDouble(amountText);

            if (IncomeDAO.addIncome(amount, source, date)) {
                outputArea.append("Income added successfully! Amount: $" + amount + ", Source: " + source + ", Date: "
                        + date + "\n");
                incomeAmountField.setText("");
                incomeSourceField.setText("");
                incomeDateField.setText("");
            } else {
                outputArea.append("Failed to add income!\n");
            }
        } catch (NumberFormatException e) {
            outputArea.append("Invalid amount format. Please enter a valid number.\n");
        }
    }

    private void addExpense() {
        try {
            String amountText = expenseAmountField.getText().trim();
            String category = expenseCategoryField.getText().trim();
            String date = expenseDateField.getText().trim();

            if (amountText.isEmpty() || category.isEmpty() || date.isEmpty()) {
                outputArea.append("Please fill in all expense fields\n");
                return;
            }

            double amount = Double.parseDouble(amountText);

            if (ExpenseDAO.addExpense(amount, category, date)) {
                DataStore.addExpense(amount);
                outputArea.append("Expense added successfully! Amount: $" + amount + ", Category: " + category
                        + ", Date: " + date + "\n");
                expenseAmountField.setText("");
                expenseCategoryField.setText("");
                expenseDateField.setText("");
            } else {
                outputArea.append("Failed to add expense!\n");
            }
        } catch (NumberFormatException e) {
            outputArea.append("Invalid amount format. Please enter a valid number.\n");
        }
    }

    private JPanel createHistorySearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 8, 4, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Advanced Search Controls
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.15;
        panel.add(new JLabel("Type:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.2;
        searchTypeCombo = new JComboBox<>(new String[] { "All", "Income", "Expense" });
        searchTypeCombo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        panel.add(searchTypeCombo, gbc);

        gbc.gridx = 2;
        gbc.weightx = 0.15;
        panel.add(new JLabel("Sort:"), gbc);

        gbc.gridx = 3;
        gbc.weightx = 0.2;
        searchSortCombo = new JComboBox<>(new String[] { "Date Desc", "Date Asc", "Amount Desc", "Amount Asc" });
        searchSortCombo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        panel.add(searchSortCombo, gbc);

        gbc.gridx = 4;
        gbc.weightx = 0.15;
        panel.add(new JLabel("Keyword:"), gbc);

        gbc.gridx = 5;
        gbc.weightx = 0.25;
        searchKeywordField = new JTextField(10);
        searchKeywordField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchKeywordField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchKeywordField.setToolTipText("Search in description or category");
        panel.add(searchKeywordField, gbc);

        // Date Range Search
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.15;
        panel.add(new JLabel("Date Range:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.2;
        searchDateField = new JTextField(10);
        searchDateField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchDateField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchDateField.setToolTipText("YYYY-MM-DD or YYYY-MM-DD to YYYY-MM-DD");
        panel.add(searchDateField, gbc);

        gbc.gridx = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 0.35;
        JButton searchRangeButton = createButton("Search Range");
        searchRangeButton.addActionListener(e -> searchDateRange());
        panel.add(searchRangeButton, gbc);

        // Quick Search Buttons
        gbc.gridx = 4;
        gbc.gridwidth = 1;
        gbc.weightx = 0.15;
        JButton searchTodayButton = createButton("Today");
        searchTodayButton.addActionListener(e -> searchToday());
        panel.add(searchTodayButton, gbc);

        gbc.gridx = 5;
        gbc.weightx = 0.15;
        JButton searchThisMonthButton = createButton("This Month");
        searchThisMonthButton.addActionListener(e -> searchThisMonth());
        panel.add(searchThisMonthButton, gbc);

        // Period Search
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 0.15;
        panel.add(new JLabel("Month:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.2;
        searchMonthField = new JTextField(10);
        searchMonthField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchMonthField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchMonthField.setToolTipText("MM format (01-12)");
        panel.add(searchMonthField, gbc);

        gbc.gridx = 2;
        gbc.weightx = 0.15;
        panel.add(new JLabel("Year:"), gbc);

        gbc.gridx = 3;
        gbc.weightx = 0.2;
        searchYearField = new JTextField(10);
        searchYearField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchYearField.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        searchYearField.setToolTipText("YYYY format");
        panel.add(searchYearField, gbc);

        gbc.gridx = 4;
        gbc.weightx = 0.15;
        JButton searchMonthlyButton = createButton("Search Month");
        searchMonthlyButton.addActionListener(e -> searchMonthly());
        panel.add(searchMonthlyButton, gbc);

        gbc.gridx = 5;
        gbc.weightx = 0.15;
        JButton searchYearlyButton = createButton("Search Year");
        searchYearlyButton.addActionListener(e -> searchYearly());
        panel.add(searchYearlyButton, gbc);

        // Clear and Export Buttons
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3;
        gbc.weightx = 0.45;
        JButton clearSearchButton = createButton("Clear Search");
        clearSearchButton.addActionListener(e -> clearSearch());
        panel.add(clearSearchButton, gbc);

        gbc.gridx = 3;
        gbc.gridwidth = 3;
        gbc.weightx = 0.45;
        JButton exportSearchButton = createButton("Export Results");
        exportSearchButton.addActionListener(e -> exportSearchResults());
        panel.add(exportSearchButton, gbc);

        return panel;
    }

    private void searchDaily() {
        String date = searchDateField.getText().trim();
        if (date.isEmpty()) {
            outputArea.append("Please enter a date (YYYY-MM-DD)\n");
            return;
        }

        performAdvancedSearch("DATE(date) = DATE(?)", date, "Daily History (" + date + ")");
    }

    private void searchMonthly() {
        String month = searchMonthField.getText().trim();
        if (month.isEmpty()) {
            outputArea.append("Please enter a month (MM)\n");
            return;
        }

        performAdvancedSearch("MONTH(date) = ?", month, "Monthly History (Month " + month + ")");
    }

    private void searchYearly() {
        String year = searchYearField.getText().trim();
        if (year.isEmpty()) {
            outputArea.append("Please enter a year (YYYY)\n");
            return;
        }

        performAdvancedSearch("YEAR(date) = ?", year, "Yearly History (Year " + year + ")");
    }

    private void searchDateRange() {
        String dateRange = searchDateField.getText().trim();
        if (dateRange.isEmpty()) {
            outputArea.append("Please enter a date range (YYYY-MM-DD or YYYY-MM-DD to YYYY-MM-DD)\n");
            return;
        }

        String dateCondition;
        if (dateRange.contains(" to ")) {
            String[] dates = dateRange.split(" to ");
            dateCondition = "date BETWEEN ? AND ?";
            performAdvancedSearch(dateCondition, dates, "Date Range History (" + dateRange + ")");
        } else {
            dateCondition = "DATE(date) = DATE(?)";
            performAdvancedSearch(dateCondition, dateRange, "Date History (" + dateRange + ")");
        }
    }

    private void searchToday() {
        performAdvancedSearch("DATE(date) = CURDATE()", "", "Today's History");
    }

    private void searchThisMonth() {
        performAdvancedSearch("MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())", "",
                "This Month's History");
    }

    private void performAdvancedSearch(String dateCondition, Object dateParams, String title) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finance_db", "root",
                "RamMane214#")) {
            StringBuilder sql = new StringBuilder(
                    "SELECT type, amount, description, category, date FROM transactions WHERE ");
            sql.append(dateCondition);

            // Add type filter
            String selectedType = (String) searchTypeCombo.getSelectedItem();
            if (!"All".equals(selectedType)) {
                sql.append(" AND type = ?");
            }

            // Add keyword filter
            String keyword = searchKeywordField.getText().trim();
            if (!keyword.isEmpty()) {
                sql.append(" AND (description LIKE ? OR category LIKE ?)");
            }

            // Add sorting
            String selectedSort = (String) searchSortCombo.getSelectedItem();
            switch (selectedSort) {
                case "Date Asc":
                    sql.append(" ORDER BY date ASC");
                    break;
                case "Amount Desc":
                    sql.append(" ORDER BY amount DESC");
                    break;
                case "Amount Asc":
                    sql.append(" ORDER BY amount ASC");
                    break;
                default: // Date Desc
                    sql.append(" ORDER BY date DESC");
            }

            PreparedStatement pstmt = conn.prepareStatement(sql.toString());

            // Set parameters
            int paramIndex = 1;

            // Set date parameters
            if (dateParams instanceof Object[]) {
                Object[] dates = (Object[]) dateParams;
                for (Object date : dates) {
                    pstmt.setString(paramIndex++, date.toString());
                }
            } else if (!dateParams.toString().isEmpty()) {
                pstmt.setString(paramIndex++, dateParams.toString());
            }

            // Set type parameter
            if (!"All".equals(selectedType)) {
                pstmt.setString(paramIndex++, selectedType.toLowerCase());
            }

            // Set keyword parameters
            if (!keyword.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + keyword + "%");
                pstmt.setString(paramIndex++, "%" + keyword + "%");
            }

            ResultSet rs = pstmt.executeQuery();

            outputArea.append("\n=== " + title.toUpperCase() + " ===\n");
            boolean found = false;
            double totalIncome = 0, totalExpense = 0;
            int transactionCount = 0;

            while (rs.next()) {
                found = true;
                transactionCount++;
                String type = rs.getString("type");
                double amount = rs.getDouble("amount");
                String description = rs.getString("description");
                String category = rs.getString("category");
                String transactionDate = rs.getString("date");

                if ("income".equals(type)) {
                    totalIncome += amount;
                    outputArea.append(String.format("INCOME:  $%,.2f from %s (%s) [%s]\n",
                            amount, description, transactionDate, category));
                } else {
                    totalExpense += amount;
                    outputArea.append(String.format("EXPENSE: $%,.2f for %s (%s) [%s]\n",
                            amount, description, transactionDate, category));
                }
            }

            if (found) {
                outputArea.append("\n--- SEARCH SUMMARY ---\n");
                outputArea.append(String.format("Total Transactions: %d\n", transactionCount));
                outputArea.append(String.format("Total Income:     $%,.2f\n", totalIncome));
                outputArea.append(String.format("Total Expense:    $%,.2f\n", totalExpense));
                outputArea.append(String.format("Net Balance:      $%,.2f\n", totalIncome - totalExpense));
                outputArea.append(String.format("Average Transaction: $%,.2f\n",
                        (totalIncome + totalExpense) / transactionCount));

                if (!keyword.isEmpty()) {
                    outputArea.append(String.format("Keyword Filter:   '%s'\n", keyword));
                }
                if (!"All".equals(selectedType)) {
                    outputArea.append(String.format("Type Filter:       '%s'\n", selectedType));
                }
            } else {
                outputArea.append("No transactions found matching your criteria.\n");
            }
            outputArea.append("=====================================\n\n");

        } catch (SQLException e) {
            outputArea.append("Error searching history: " + e.getMessage() + "\n");
        }
    }

    private void clearSearch() {
        searchDateField.setText("");
        searchMonthField.setText("");
        searchYearField.setText("");
        searchKeywordField.setText("");
        searchTypeCombo.setSelectedIndex(0);
        searchSortCombo.setSelectedIndex(0);
        outputArea.append("Search fields cleared.\n");
    }

    private void exportSearchResults() {
        // Get current text from output area
        String content = outputArea.getText();

        // Create a simple text export
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Search Results");
        fileChooser.setSelectedFile(new java.io.File("finance_search_results.txt"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            java.io.File fileToSave = fileChooser.getSelectedFile();
            try {
                java.io.FileWriter writer = new java.io.FileWriter(fileToSave);
                writer.write("FINANCE TRACKER - SEARCH RESULTS\n");
                writer.write("Generated: " + new java.util.Date() + "\n");
                writer.write("=====================================\n\n");
                writer.write(content);
                writer.close();
                outputArea.append("Results exported to: " + fileToSave.getAbsolutePath() + "\n");
            } catch (Exception e) {
                outputArea.append("Error exporting results: " + e.getMessage() + "\n");
            }
        }
    }

    private void openHistoryPage() {
        SwingUtilities.invokeLater(() -> {
            try {
                HistoryPage historyPage = new HistoryPage();
                historyPage.setVisible(true);
            } catch (Exception e) {
                outputArea.append("Error opening history page: " + e.getMessage() + "\n");
            }
        });
    }

    private void stopBudgetAlert() {
        if (budgetAlert != null) {
            budgetAlert.stopMonitoring();
            outputArea.append("Budget alert monitoring stopped.\n");
        } else {
            outputArea.append("Budget alert is not running.\n");
        }
    }

    private void exitApplication() {
        budgetAlert.stopMonitoring();
        outputArea.append("Goodbye!\n");

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    FinanceTrackerGUI gui = new FinanceTrackerGUI();
                    gui.setVisible(true);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error starting application: " + e.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                }
            }
        });
    }
}
