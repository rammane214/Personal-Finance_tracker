package com.finance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ExpenseDAO {
    public static boolean addExpense(double amount, String category, String date) {
        String sql = "INSERT INTO expense (amount, category, date) VALUES (?, ?, ?)";

        try {
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                System.out.println("Error: Database connection failed");
                return false;
            }

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setDouble(1, amount);
                pstmt.setString(2, category);
                pstmt.setString(3, date);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println("Expense added - Rows affected: " + rowsAffected);
                return rowsAffected > 0;
            } finally {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Error adding expense: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
